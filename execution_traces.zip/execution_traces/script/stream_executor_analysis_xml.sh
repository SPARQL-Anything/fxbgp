#!/bin/bash

source functions.sh

JAR=$1
INPUT_FOLDER=$2
RESULT_FOLDER=$3

MEM=50
EXECUTOR="stream"
SIZE="100000"
FORMAT="xml"
QTs=("H=2_K=1000T" "H=3_K=100T" "H=4_K=32T" "H=5_K=16T" "H=6_K=10T")

MAX_TPs=10
for ((TPs=3; TPs<=MAX_TPs; TPs++)); do
    inner_limit=$(( TPs * 2 + 1 ))
    for ((VARs=1; VARs<=inner_limit; VARs++)); do
      for ((RUN=1; RUN<=3; RUN++)); do
        for QT in "${QTs[@]}"; do

          UC="${QT} ${TPs} ${VARs} 0 ${SIZE} ${FORMAT}"
          echo "UC ${UC} ${RUN}"
          monitor-query-stream ${JAR} ${MEM} ${INPUT_FOLDER} ${UC} ${EXECUTOR} ${RESULT_FOLDER} ${RUN} 5

          UC="${QT} ${TPs} ${VARs} 1 ${SIZE} ${FORMAT}"
          echo "UC ${UC} ${RUN}"
          monitor-query-stream ${JAR} ${MEM} ${INPUT_FOLDER} ${UC} ${EXECUTOR} ${RESULT_FOLDER} ${RUN} 5

        done
      done
    done
done