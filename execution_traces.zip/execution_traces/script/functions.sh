#!/bin/bash


function monitor-query-stream {

  JAR=$1
  MEM=$2
  INPUT_FOLDER=$3
  D=$4
  TPs=$5
  VARs=$6
  PVARS=$7
  SIZE=$8
  FORMAT=$9
  EXECUTOR=${10}
  RESULT_FOLDER=${11}
  RUN=${12}

  TIMEOUT=360000
  if [ -n "${13}" ]; then
      TIMEOUT=${13}
  fi

  TIME_FILE="${RESULT_FOLDER}/time.tsv"
  MEM_FILE="$RESULT_FOLDER/MEM_${D}_${TPs}_${VARs}_${PVARS}_${SIZE}_${FORMAT}_${EXECUTOR}${RUN}.tsv"
  ERR_FILE="$RESULT_FOLDER/ERR_${D}_${TPs}_${VARs}_${PVARS}_${SIZE}_${FORMAT}_${EXECUTOR}${RUN}.tsv"
  MEM_RECORDS="MemoryLimit\tPID\t%cpu\t%mem\tvsz\trss\n"

  # echo "$INPUT_FOLDER $D $TPs $VARs $PVARS $SIZE $FORMAT $EXECUTOR $TIMEOUT"

  java "-Xmx${MEM}m" -jar $JAR $INPUT_FOLDER $D $TPs $VARs $PVARS $SIZE $FORMAT $EXECUTOR $TIMEOUT  2>"$ERR_FILE" >> ${TIME_FILE} &

  MPID=$!

  while kill -0 $MPID 2>/dev/null; do
    PS_RECORD="$MEM $(ps -p $MPID -o pid,%cpu,%mem,vsz,rss | sed 1d)\n"
    PS_RECORD=$(echo "$PS_RECORD" | sed -E 's/ +/\t/g')
    PS_RECORD_TRIM=$(echo "$PS_RECORD" | sed -E 's/^ +| +$//g')
    if [ -n "$PS_RECORD_TRIM" ]; then
        MEM_RECORDS+=$PS_RECORD_TRIM
    fi

    sleep 0.2
  done

  echo -n -e "$MEM_RECORDS" | tr ' ' '\t' > $MEM_FILE

}
