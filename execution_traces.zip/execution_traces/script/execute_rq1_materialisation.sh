#!/bin/bash

source functions.sh

JAR=$1
INPUT_FOLDER=$2
RESULT_FOLDER=$3

MEM=4096
EXECUTOR="materialisation"

UCs=(
   "H_1 1 3 1 10000 csv" # 
   "H_1 1 3 1 100000 csv" # 
   "H_1 1 3 1 500000 csv" # 
   "H_1 1 3 1 1000000 csv" # 
   "H_1 10 11 0 1000000 csv" #
   "H_1 10 11 1 1000000 csv" #
   "H_1 1 3 1 2000000 csv" #
   "H_1 5 6 0 2000000 csv" #
   "H_1 6 7 0 2000000 csv" #
   "H_1 7 8 0 2000000 csv" #
   "H_1 8 9 0 2000000 csv" #
   "H_1 9 10 0 2000000 csv" #
   "H_1 10 11 0 2000000 csv" #
   "H_1 4 5 0 2000000 csv" #
)


for UC in "${UCs[@]}"; do
  echo "$(date '+%Y-%m-%d %H:%M:%S') Execute ${UC} RUN #${RUN}"
  monitor-query-stream ${JAR} ${MEM} ${INPUT_FOLDER} ${UC} ${EXECUTOR} ${RESULT_FOLDER} 1
done