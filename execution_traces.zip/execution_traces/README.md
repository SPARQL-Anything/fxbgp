# ISWC 2026 — Experimental Materials

This repository contains the materials used in the experiments described in the paper submitted to ISWC 2026. It includes the executable, the scripts to run the experiments, and the execution traces for all research questions.

---

## Repository Structure

```
materials/
├── script/       # Shell scripts to launch the experiments
├── rq1/          # Execution traces for Research Question 1
└── rq2/          # Execution traces for Research Question 2
```

---

## script/

Contains the shell scripts to reproduce the experiments.

| File | Description |
|------|-------------|
| `functions.sh` | Shared utility functions used by the other scripts |
| `execute_rq1_materialisation.sh` | Launches the RQ1 materialisation experiments |
| `stream_executor_analysis_csv.sh` | Launches the RQ2 stream experiments on CSV input |
| `stream_executor_analysis_json.sh` | Launches the RQ2 stream experiments on JSON input |
| `stream_executor_analysis_xml.sh` | Launches the RQ2 stream experiments on XML input |

---

## rq1/

Contains the execution traces for **Research Question 1**, organised into two execution modes: **materialisation** and **stream**.

### rq1/input/

| Entry | Description |
|-------|-------------|
| `<number_of_records>.<format>` | Input data files, named by record count and format |
| `csv_queries/` | Directory containing the queries in CSV format |
| `rowTypes.csv` | Describes the row types used in the experiments |

### rq1/materialisation/ and rq1/stream/

Each subdirectory contains the execution traces produced by running the experiments in the respective mode. Files follow this naming convention:

**Error traces:**
```
ERR_H_<height>_<triple_patterns>_<variables>_<variables_on_predicate>_<number_of_records>_<format>_<executor><RUN>.tsv
```

**Memory traces:**
```
MEM_<height>_<triple_patterns>_<variables>_<variables_on_predicate>_<number_of_records>_<format>_<executor><RUN>.tsv
```

**Timing summary:**
```
time.tsv
```

#### Filename Parameters

| Parameter | Description |
|-----------|-------------|
| `height` | Height of the query tree |
| `triple_patterns` | Number of triple patterns in the query |
| `variables` | Number of variables in the query |
| `variables_on_predicate` | Number of variables appearing in predicate position |
| `number_of_records` | Size of the input dataset (number of records) |
| `format` | Input data format (e.g., `csv`, `json`, `xml`) |
| `executor` | Identifier of the executor configuration used |
| `RUN` | Run index (for repeated executions) |

---

## rq2/

Contains the execution traces for **Research Question 2**, organised by input format.

```
rq2/
├── csv/
│   └── stream-performance-csv/  # Stream performance traces for CSV
├── json/
│   └── stream-performance-json/ # Stream performance traces for JSON
└── xml/
    └── stream-performance-xml/  # Stream performance traces for XML
```

Each `stream-performance-<format>/` directory contains the execution traces (timing, memory, and errors) produced during the stream processing experiments for the corresponding input format.

---

## Requirements

- **Java** — to run the executor JAR
- **Bash** — to run the experiment scripts

---

## Reproducibility

To reproduce the RQ1 materialisation experiments:

```bash
cd script/
bash execute_rq1_materialisation.sh <EXECUTOR> <INPUT_FOLDER> <OUTPUT_FOLDER>
```

To reproduce the RQ2 stream experiments for a specific format:

```bash
cd script/
bash stream_executor_analysis_csv.sh  <EXECUTOR> <INPUT_FOLDER> <OUTPUT_FOLDER> # for CSV
bash stream_executor_analysis_json.sh <EXECUTOR> <INPUT_FOLDER> <OUTPUT_FOLDER> # for JSON
bash stream_executor_analysis_xml.sh  <EXECUTOR> <INPUT_FOLDER> <OUTPUT_FOLDER> # for XML
```